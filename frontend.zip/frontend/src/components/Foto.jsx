import react from 'react';
import './imagen.css';




function Foto() {

    return (
        <div className='contenedor'>
        <img src="/foto1.png" alt="logo" className='imagen'/>
        </div>
    );




}

export default Foto;